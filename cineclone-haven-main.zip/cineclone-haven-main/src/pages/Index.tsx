
import { useEffect } from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import Hero from '@/components/home/Hero';
import FeaturedContent from '@/components/home/FeaturedContent';
import TrendingNow from '@/components/home/TrendingNow';

const Index = () => {
  useEffect(() => {
    // Set dark mode by default for streaming site aesthetic
    document.documentElement.classList.add('dark');
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      
      <main>
        <Hero />
        
        <FeaturedContent 
          title="Popular on CineZub" 
          subtitle="The most watched titles this week"
        />
        
        <TrendingNow />
        
        <FeaturedContent 
          title="New Releases" 
          subtitle="Recently added to our collection"
        />
        
        <FeaturedContent 
          title="Award Winners" 
          subtitle="Critically acclaimed movies and shows"
        />
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
