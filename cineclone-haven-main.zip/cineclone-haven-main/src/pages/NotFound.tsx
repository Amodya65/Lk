
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  useEffect(() => {
    // Set dark mode by default for streaming site aesthetic
    document.documentElement.classList.add('dark');
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      
      <main className="min-h-screen flex items-center justify-center pt-20">
        <div className="text-center max-w-md px-4">
          <h1 className="text-6xl font-bold mb-6 animate-fade-in">404</h1>
          <p className="text-xl text-gray-300 mb-8 animate-fade-in delay-100">
            Oops! We couldn't find the content you're looking for.
          </p>
          <p className="text-gray-400 mb-8 animate-fade-in delay-200">
            The title might have been removed or the URL might be incorrect.
          </p>
          <Button asChild className="bg-white hover:bg-gray-200 text-black animate-fade-in delay-300">
            <Link to="/">
              Return to Home
            </Link>
          </Button>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default NotFound;
