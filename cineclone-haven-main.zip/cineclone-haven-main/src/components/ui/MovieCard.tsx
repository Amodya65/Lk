
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Play, Plus, ThumbsUp, Info } from 'lucide-react';

interface MovieCardProps {
  id: number;
  title: string;
  image: string;
  year: number;
  rating: string;
  category?: string;
  className?: string;
}

const MovieCard = ({ id, title, image, year, rating, category, className }: MovieCardProps) => {
  const [isLoaded, setIsLoaded] = useState(false);
  
  return (
    <div className={cn("movie-card group", className)}>
      {/* Image Container */}
      <div className="lazy-image-container w-full h-full aspect-[2/3]">
        <img
          src={image}
          alt={title}
          className={cn(
            "lazy-image w-full h-full object-cover",
            isLoaded ? "lazy-image-loaded" : "lazy-image-loading"
          )}
          onLoad={() => setIsLoaded(true)}
        />
        
        {/* Hover Overlay */}
        <div className="movie-card-hover">
          <div className="flex justify-between items-center mb-2">
            <button className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center hover:bg-gray-200 transition-colors">
              <Play className="w-5 h-5" />
            </button>
            
            <div className="flex space-x-2">
              <button className="w-8 h-8 rounded-full border-2 border-gray-400 flex items-center justify-center hover:border-white transition-colors">
                <Plus className="w-4 h-4 text-white" />
              </button>
              <button className="w-8 h-8 rounded-full border-2 border-gray-400 flex items-center justify-center hover:border-white transition-colors">
                <ThumbsUp className="w-4 h-4 text-white" />
              </button>
              <button className="w-8 h-8 rounded-full border-2 border-gray-400 flex items-center justify-center hover:border-white transition-colors">
                <Info className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
          
          <h3 className="font-bold text-white text-lg mb-1 line-clamp-1">{title}</h3>
          
          <div className="flex items-center text-gray-300 text-sm space-x-3">
            <span>{year}</span>
            <span className="w-1 h-1 rounded-full bg-gray-400"></span>
            <span>{rating}</span>
          </div>
          
          {category && (
            <span className="mt-2 inline-block px-2 py-1 bg-gray-800 text-white text-xs rounded">
              {category}
            </span>
          )}
        </div>
      </div>
      
      {/* Gradient overlay at bottom */}
      <div className="absolute inset-x-0 bottom-0 h-16 bg-card-gradient pointer-events-none"></div>
    </div>
  );
};

export default MovieCard;
