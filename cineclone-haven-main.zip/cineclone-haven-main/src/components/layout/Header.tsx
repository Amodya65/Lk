
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, Bell, User } from 'lucide-react';
import { cn } from '@/lib/utils';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setIsScrolled(offset > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 py-4 transition-all duration-300",
      isScrolled ? "blur-backdrop py-3" : "bg-transparent"
    )}>
      <div className="container mx-auto px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center">
          <Link to="/" className="text-3xl font-bold text-white animate-fade-in">
            Cine<span className="text-cinema-400">Zub</span>
          </Link>
          
          <nav className="hidden md:flex ml-10 space-x-1">
            <Link to="/" className="nav-link nav-link-active">Home</Link>
            <Link to="/movies" className="nav-link">Movies</Link>
            <Link to="/tv-shows" className="nav-link">TV Shows</Link>
            <Link to="/new" className="nav-link">New & Popular</Link>
            <Link to="/my-list" className="nav-link">My List</Link>
          </nav>
        </div>
        
        <div className="flex items-center space-x-6">
          <button className="text-white opacity-80 hover:opacity-100 transition-opacity">
            <Search className="w-5 h-5" />
          </button>
          <button className="text-white opacity-80 hover:opacity-100 transition-opacity">
            <Bell className="w-5 h-5" />
          </button>
          <button className="flex items-center text-white opacity-80 hover:opacity-100 transition-opacity">
            <User className="w-5 h-5" />
          </button>
          
          <button 
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth="2" 
                d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
              />
            </svg>
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-black/95 border-b border-gray-800 animate-slide-down">
          <nav className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link to="/" className="text-white py-2 px-3 rounded hover:bg-gray-800">Home</Link>
            <Link to="/movies" className="text-white py-2 px-3 rounded hover:bg-gray-800">Movies</Link>
            <Link to="/tv-shows" className="text-white py-2 px-3 rounded hover:bg-gray-800">TV Shows</Link>
            <Link to="/new" className="text-white py-2 px-3 rounded hover:bg-gray-800">New & Popular</Link>
            <Link to="/my-list" className="text-white py-2 px-3 rounded hover:bg-gray-800">My List</Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
