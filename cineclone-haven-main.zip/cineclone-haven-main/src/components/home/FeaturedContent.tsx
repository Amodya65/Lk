
import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import MovieCard from '@/components/ui/MovieCard';

interface FeaturedContentProps {
  title: string;
  subtitle?: string;
}

const featuredMovies = [
  {
    id: 1,
    title: "The Shawshank Redemption",
    image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1925&auto=format&fit=crop",
    year: 1994,
    rating: "R",
    category: "Drama"
  },
  {
    id: 2,
    title: "The Godfather",
    image: "https://images.unsplash.com/photo-1604975701397-6365ccbd028a?q=80&w=2127&auto=format&fit=crop",
    year: 1972,
    rating: "R",
    category: "Crime"
  },
  {
    id: 3,
    title: "The Dark Knight",
    image: "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?q=80&w=2036&auto=format&fit=crop",
    year: 2008,
    rating: "PG-13",
    category: "Action"
  },
  {
    id: 4,
    title: "Pulp Fiction",
    image: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?q=80&w=2070&auto=format&fit=crop",
    year: 1994,
    rating: "R",
    category: "Crime"
  },
  {
    id: 5,
    title: "The Lord of the Rings",
    image: "https://images.unsplash.com/photo-1574267432553-4b4628081c31?q=80&w=1931&auto=format&fit=crop",
    year: 2001,
    rating: "PG-13",
    category: "Adventure"
  },
  {
    id: 6,
    title: "Inception",
    image: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?q=80&w=2070&auto=format&fit=crop",
    year: 2010,
    rating: "PG-13",
    category: "Sci-Fi"
  },
  {
    id: 7,
    title: "Fight Club",
    image: "https://images.unsplash.com/photo-1508807526345-15e9b5f4eaff?q=80&w=2070&auto=format&fit=crop",
    year: 1999,
    rating: "R",
    category: "Drama"
  },
  {
    id: 8,
    title: "Forrest Gump",
    image: "https://images.unsplash.com/photo-1586227740560-8cf2732c1531?q=80&w=1961&auto=format&fit=crop",
    year: 1994,
    rating: "PG-13",
    category: "Drama"
  }
];

const FeaturedContent = ({ title, subtitle }: FeaturedContentProps) => {
  const sliderRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const { current } = sliderRef;
      const scrollAmount = current.clientWidth * 0.75;
      
      if (direction === 'left') {
        current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      } else {
        current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }
  };

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-6">
          <div>
            <h2 className="text-2xl font-bold">{title}</h2>
            {subtitle && <p className="text-gray-400 mt-1">{subtitle}</p>}
          </div>
          
          <div className="hidden md:flex space-x-2">
            <button 
              onClick={() => scroll('left')}
              className="p-2 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button 
              onClick={() => scroll('right')}
              className="p-2 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        <div className="relative">
          <div 
            ref={sliderRef}
            className="flex overflow-x-auto gap-4 pb-4 scrollbar-hide" 
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {featuredMovies.map((movie) => (
              <div key={movie.id} className="flex-none w-[180px] md:w-[220px]">
                <MovieCard
                  id={movie.id}
                  title={movie.title}
                  image={movie.image}
                  year={movie.year}
                  rating={movie.rating}
                  category={movie.category}
                />
              </div>
            ))}
          </div>
          
          {/* Gradient fades at the edges for visual polish */}
          <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-background to-transparent pointer-events-none"></div>
          <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-background to-transparent pointer-events-none"></div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedContent;
