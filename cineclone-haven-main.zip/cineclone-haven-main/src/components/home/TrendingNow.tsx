
import { useRef } from 'react';
import { ChevronLeft, ChevronRight, TrendingUp } from 'lucide-react';
import MovieCard from '@/components/ui/MovieCard';
import { cn } from '@/lib/utils';

const trendingMovies = [
  {
    id: 1,
    title: "Joker",
    image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=2102&auto=format&fit=crop",
    year: 2019,
    rating: "R",
    trending: 1
  },
  {
    id: 2,
    title: "1917",
    image: "https://images.unsplash.com/photo-1547700055-b61cacebece9?q=80&w=2070&auto=format&fit=crop",
    year: 2019,
    rating: "R",
    trending: 2
  },
  {
    id: 3,
    title: "Parasite",
    image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=2070&auto=format&fit=crop",
    year: 2019,
    rating: "R",
    trending: 3
  },
  {
    id: 4,
    title: "Once Upon a Time in Hollywood",
    image: "https://images.unsplash.com/photo-1542204165-65bf26472b9b?q=80&w=1974&auto=format&fit=crop",
    year: 2019,
    rating: "R",
    trending: 4
  },
  {
    id: 5,
    title: "The Irishman",
    image: "https://images.unsplash.com/photo-1594908900066-3f47337549d8?q=80&w=2070&auto=format&fit=crop",
    year: 2019,
    rating: "R",
    trending: 5
  },
  {
    id: 6,
    title: "Marriage Story",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=2070&auto=format&fit=crop",
    year: 2019,
    rating: "R",
    trending: 6
  },
  {
    id: 7,
    title: "Little Women",
    image: "https://images.unsplash.com/photo-1551818255-e6e10975bc17?q=80&w=2073&auto=format&fit=crop",
    year: 2019,
    rating: "PG",
    trending: 7
  },
  {
    id: 8,
    title: "Knives Out",
    image: "https://images.unsplash.com/photo-1505686994434-e3cc5abf1330?q=80&w=2012&auto=format&fit=crop",
    year: 2019,
    rating: "PG-13",
    trending: 8
  }
];

const TrendingNow = () => {
  const sliderRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const { current } = sliderRef;
      const scrollAmount = current.clientWidth * 0.75;
      
      if (direction === 'left') {
        current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      } else {
        current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }
  };

  return (
    <section className="py-12 bg-black/5 dark:bg-white/5">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-cinema-500" />
            <h2 className="text-2xl font-bold">Trending Now</h2>
          </div>
          
          <div className="hidden md:flex space-x-2">
            <button 
              onClick={() => scroll('left')}
              className="p-2 rounded-full bg-black/20 hover:bg-black/40 text-foreground transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button 
              onClick={() => scroll('right')}
              className="p-2 rounded-full bg-black/20 hover:bg-black/40 text-foreground transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        <div className="relative">
          <div 
            ref={sliderRef}
            className="flex overflow-x-auto gap-4 pb-4 scrollbar-hide"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}  
          >
            {trendingMovies.map((movie) => (
              <div key={movie.id} className="flex-none w-[220px] md:w-[280px] relative">
                <MovieCard
                  id={movie.id}
                  title={movie.title}
                  image={movie.image}
                  year={movie.year}
                  rating={movie.rating}
                />
                <div className={cn(
                  "absolute top-2 left-2 z-10 w-8 h-8 rounded-full flex items-center justify-center",
                  movie.trending <= 3 ? "bg-cinema-500 text-white" : "bg-white/20 backdrop-blur-sm text-white"
                )}>
                  {movie.trending}
                </div>
              </div>
            ))}
          </div>
          
          {/* Gradient fades at the edges */}
          <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-background to-transparent pointer-events-none"></div>
          <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-background to-transparent pointer-events-none"></div>
        </div>
      </div>
    </section>
  );
};

export default TrendingNow;
