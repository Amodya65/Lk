
import { useState, useEffect } from 'react';
import { PlayCircle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface HeroMovie {
  id: number;
  title: string;
  description: string;
  background: string;
  year: number;
  rating: string;
  duration: string;
  genres: string[];
}

const heroMovies: HeroMovie[] = [
  {
    id: 1,
    title: "Interstellar",
    description: "When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft, along with a team of researchers, to find a new planet for humans.",
    background: "https://images.unsplash.com/photo-1610296669228-602fa827fc1f?q=80&w=2075&auto=format&fit=crop",
    year: 2014,
    rating: "PG-13",
    duration: "2h 49m",
    genres: ["Sci-Fi", "Adventure", "Drama"]
  },
  {
    id: 2,
    title: "Dune",
    description: "A noble family becomes embroiled in a war for control over the galaxy's most valuable asset while its heir becomes troubled by visions of a dark future.",
    background: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?q=80&w=2059&auto=format&fit=crop",
    year: 2021,
    rating: "PG-13",
    duration: "2h 35m",
    genres: ["Sci-Fi", "Adventure", "Drama"]
  },
  {
    id: 3,
    title: "The Batman",
    description: "When the Riddler, a sadistic serial killer, begins murdering key political figures in Gotham, Batman is forced to investigate the city's hidden corruption and question his family's involvement.",
    background: "https://images.unsplash.com/photo-1609610322045-8f1f3df4ad66?q=80&w=1925&auto=format&fit=crop",
    year: 2022,
    rating: "PG-13",
    duration: "2h 56m",
    genres: ["Action", "Crime", "Drama"]
  }
];

const Hero = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isChanging, setIsChanging] = useState(false);
  const currentMovie = heroMovies[currentIndex];
  
  useEffect(() => {
    const interval = setInterval(() => {
      setIsChanging(true);
      setTimeout(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % heroMovies.length);
        setIsChanging(false);
      }, 500);
    }, 8000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div 
        className={cn(
          "absolute inset-0 transition-opacity duration-700 ease-in-out bg-center bg-cover",
          isChanging ? "opacity-0" : "opacity-100"
        )}
        style={{ backgroundImage: `url(${currentMovie.background})` }}
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-hero-pattern z-10"></div>
      
      {/* Content */}
      <div className="container relative z-20 mx-auto px-4 h-full flex flex-col justify-end pb-24">
        <div className={cn(
          "max-w-2xl transition-all duration-500",
          isChanging ? "opacity-0 translate-y-10" : "opacity-100 translate-y-0"
        )}>
          {/* Genre Pills */}
          <div className="flex flex-wrap gap-2 mb-4">
            {currentMovie.genres.map((genre, index) => (
              <span 
                key={index} 
                className="px-3 py-1 text-xs font-medium bg-white/10 backdrop-blur-sm rounded-full text-white"
              >
                {genre}
              </span>
            ))}
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-3">{currentMovie.title}</h1>
          
          <div className="flex items-center text-gray-300 text-sm mb-4 space-x-4">
            <span>{currentMovie.year}</span>
            <span className="w-1 h-1 rounded-full bg-gray-400"></span>
            <span>{currentMovie.rating}</span>
            <span className="w-1 h-1 rounded-full bg-gray-400"></span>
            <span>{currentMovie.duration}</span>
          </div>
          
          <p className="text-gray-200 mb-8 text-lg leading-relaxed">{currentMovie.description}</p>
          
          <div className="flex flex-wrap gap-4">
            <Button className="bg-white hover:bg-gray-200 text-black rounded-md font-medium px-6 py-5">
              <PlayCircle className="mr-2 h-5 w-5" />
              Watch Now
            </Button>
            <Button variant="outline" className="text-white border-white hover:bg-white/10 rounded-md font-medium px-6 py-5">
              <Info className="mr-2 h-5 w-5" />
              More Info
            </Button>
          </div>
        </div>
      </div>
      
      {/* Slide Indicators */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20 flex space-x-2">
        {heroMovies.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setIsChanging(true);
              setTimeout(() => {
                setCurrentIndex(index);
                setIsChanging(false);
              }, 500);
            }}
            className={cn(
              "w-12 h-1.5 rounded-full transition-all duration-300",
              currentIndex === index ? "bg-white" : "bg-white/30"
            )}
          />
        ))}
      </div>
    </section>
  );
};

export default Hero;
